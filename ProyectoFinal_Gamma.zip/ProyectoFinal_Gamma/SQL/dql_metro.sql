--- EJERCICIO 3: CONSULTAS

--Ej a-- Mostrar el número de estaciones que se tienen por línea.
select a.NumeroLinea, count(b.NumeroEstacion) as NumeroEstaciones
from Linea a
join Pertenecer b on a.NumeroLinea = b.NumeroLinea
group by a.NumeroLinea
order by NumeroLinea asc;

--Ej b-- Información de los conductores que condujeron en el horario de las 5:00 a las 12:00 horas durante el primer trimestre de 2022.
SELECT distinct a.*
FROM Conductor a
JOIN Conducir b ON a.CURP = b.CURP
Where extract(QUARTER FROM b.Fecha) = 1
	AND extract(YEAR FROM b.Fecha) = 2022
	AND extract(HOUR FROM b.HoraInicio) BETWEEN 5 AND 12
	AND extract(HOUR FROM b.HoraFin) BETWEEN 5 and 12;

--Ej c-- Información de los trenes que entraron en reparación el día 03 de noviembre de 2023, indicando el hangar al que fueron enviados.
select t.IDTren, t.NumeroLinea, t.Marca, r.FechaInicio as FechaReparacion, h.IDHangar, h.NumeroEstacion as EstacionHangar
from Tren t
inner join Reservar r on t.IDTren = r.IDTren
inner join Hangar h on r.IDHangar = h.IDHangar
where r.FechaInicio = '2023-11-03'and t.Estatus = FALSE;


--Ej d-- Información de los conductores que tienen entre 40y 50 años, que conducen trenes en líneas con número impar.
SELECT distinct a.*, extract(YEAR FROM age(a.nacimiento)) edad
FROM Conductor a
JOIN Conducir b ON a.CURP = b.CURP
JOIN Tren c ON b.IDTren = c.IDTren
WHERE extract(YEAR FROM age(a.nacimiento)) BETWEEN 40 AND 50
	AND numerolinea ~ '^\d'
	AND numerolinea::INTEGER % 2 = 0;

--Ej e-- Información de las estaciones que tienen accesos con el mismo horario en que opera la estación correspondiente.
select distinct E.*
from Estacion E
join Acceso A on E.NumeroEstacion = A.NumeroEstacion
where A.HoraApertura = E.HoraApertura and A.HoraCierre = E.HoraCierre;

--Ej f-- Información de las conductoras que ganan entre $10,500.0 y $11,500.0 y que no están conduciendo, porque su tren se mandó a reparar.
SELECT distinct a.*
FROM Conductor a
JOIN Conducir b ON a.CURP = b.CURP
JOIN tren c ON b.IDTren = c.IDTren
WHERE c.Estatus = False AND a.sexo = 'F'
	AND a.Salario BETWEEN 10500 AND 11500;	

--Ej g-- Indicar el número de días que los trenes de las líneas pares estuvieron en reparación durante 2023.
select 
    t.NumeroLinea, 
    sum(r.FechaFin - r.FechaInicio) as DiasTotalesEnReparacion
from Reservar r
join Tren t on r.IDTren = t.IDTren
where extract(year from r.FechaInicio) = 2023
  and t.Estatus = FALSE
  and t.NumeroLinea in ('2', '4', '6', '8', '12') -- Filtra líneas específicas
group by t.NumeroLinea
order by t.NumeroLinea asc;

--Ej h-- Información de los conductores que no están asignados a ningún tren, cuyo primer apellido sea MARTÍNEZ.
SELECT *
FROM Conductor a
WHERE LOWER(a.paterno) = 'martínez'
	AND not exists (
		select * 
		FROM Conducir b
		WHERE a.CURP = b.CURP);

--Ej i-- Información de las estaciones que tienen conexión a otro servicio de transporte, indicando los servicios a los que se conecta.
select a.NumeroEstacion, a.NombreEstacion, b.IDServicio, c.Nombre as NombreServicio, c.Tipo as TipoServicio
from Estacion a
join Conectar b on a.NumeroEstacion = b.NumeroEstacion
join Servicio c on b.IDServicio = c.IDServicio;

--Ej j-- Mostrar para los trenes de la marca ALSTHOM, el detalle de las reservaciones que hicieron durante 2022.
SELECT R.*
FROM Tren T
JOIN Reservar R ON T.IDTren = R.IDTren
WHERE LOWER(T.Marca) = 'alsthom'
	AND extract(year FROM R.FechaInicio) = 2022;

--Ej k-- Mostrar la información las conductoras que laboran exclusivamente en horario MATUTINO.
select a.*, b.Telefono
from Conductor a
join Telefono b on a.CURP = b.CURP
where a.Sexo = 'F' and a.CURP not in (
      select CURP
      from Conducir c
      where Turno <> 'M')
order by a.Nombre asc;

--Ej l-- Mostrar el total de trenes por línea, marca y estatus.
SELECT T.NumeroLinea, T.Marca, T.Estatus, COUNT(*) AS trenes_totales
FROM Tren T
GROUP BY T.NumeroLinea, T.Marca, T.Estatus
ORDER BY T.NumeroLinea, T.Marca, T.Estatus;

--Ej m-- Información de las reservaciones y trenes que se tienen por hangar, para las estaciones impares.
SELECT a.NumeroEstacion, c.IDHangar, c.FechaInicio, c.FechaFin, d.*
FROM Estacion a
NATURAL JOIN Hangar b 
NATURAL JOIN Reservar c
Natural JOIN Tren d
WHERE a.NumeroEstacion % 2 = 1
ORDER BY a.NumeroEstacion asc;

--Ej n-- Información de las estaciones que no tienen ningún hangar asociado.
SELECT *
FROM Estacion Est
WHERE Est.NumeroEstacion NOT IN (
	SELECT H.NumeroEstacion
	FROM Hangar H);

--Ej o-- Número de conductores menores a treinta años, por estado de procedencia y sexo.
select Estado,Sexo,
count(*) as NumeroConductores
from Conductor
where DATE_PART('year', AGE(Nacimiento)) < 30
group by Estado, Sexo
order by Estado, Sexo;

--Ej p-- Información de los conductores de 35 a 55 años que conduzcan trenes de la marca BOMBARDIER y que tengan asignados turnos VESPERTINO y NOCTURNO.
SELECT distinct a.*, extract(YEAR FROM age(a.nacimiento)) edad
FROM Conductor a
JOIN Conducir b ON a.CURP = b.CURP
JOIN Tren T ON b.IDTren = T.IDTren
WHERE extract(YEAR FROM age(a.nacimiento)) BETWEEN 35 AND 55
	AND LOWER(T.Marca) = 'bombardier'
	AND b.Turno IN ('V','N');

--Ej q-- Información de los conductores y tengan la cadena ALONSO en cualquier posición y que ganen más que el salario promedio.
select *
from Conductor
where (Nombre ilike '%ALONSO%' or Paterno ilike '%ALONSO%' or Materno ilike '%ALONSO%') and Salario > (select avg(Salario) from Conductor);

--Ej r-- Trenes que tengan 9 vagones que sean de la marca CONCARRIL.
SELECT *
FROM Tren 
WHERE Tren.Vagones = 9
	AND LOWER(Tren.Marca) = 'concarril';

--Ej s-- Información de los conductores que manejen trenes con año de fabricación posterior al 2021.
select a.*
from Conductor a
join Conducir b on a.CURP = b.CURP
join Tren c on b.IDTren = c.IDTren
where c.AnioFabrica > 2021
order by a.Nombre asc;

--Ej t-- Obtener una lista de los conductores cuyo apellido paterno comience con las letras A, D, G, J, L, P o R.
SELECT *
FROM Conductor
WHERE Conductor.Paterno ~* '^[ADGJLPR]'
ORDER BY Conductor.Paterno;

--Ej u-- Obtener la información de los trenes al día 03 de noviembre de 2023 no hayan salido de reparación.
select *
from Tren a
where a.Estatus = FALSE and not exists (
      select *
      from Conducir b
      where b.IDTren = a.IDTren and b.Fecha <= '2023-11-03');

--Ej v-- Un reporte que indique el número de reparaciones que han tenido los trenes, por marca.
SELECT T.Marca, COUNT(*) num_reparacion
FROM Tren T
WHERE T.Estatus = False
GROUP BY T.Marca;

--Ej w-- Incrementar en un 10% el salario de los conductores que tengan 50 años.
update Conductor
set Salario = Salario * 1.10
where DATE_PART('year', AGE(Nacimiento)) = 50;

	-- Consulta correspondiente
	/*
	SELECT *
	FROM Conductor
	WHERE DATE_PART('year', AGE(Nacimiento)) = 50;
	*/


--Ej x-- Borrar toda la información de los trenes de la marca BOMBARDIER que tengan más de 30 años de servicio.
DELETE FROM Tren 
WHERE LOWER(Marca) = 'bombardier' 
	AND EXTRACT (year FROM now()) - AnioFabrica >30;

	-- Consulta Correspondiente
	/*
	SELECT *
	FROM Tren
	WHERE LOWER(Marca) = 'bombardier' 
		AND EXTRACT (year FROM now()) - AnioFabrica >30;
	*/
	

--Ej y-- Insertar una flota de 10 trenes de la marca Construcciones y Auxiliar de Ferrocarriles (CAF) que fueron construidos
-- en 2023 y que serán distribuidos de manera equitativa en las líneas A y B.

insert into Tren
values
    (1, 'A', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (2, 'A', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (3, 'A', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (4, 'A', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (5, 'A', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (6, 'B', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (7, 'B', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (8, 'B', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (9, 'B', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023),
    (10, 'B', 'Construcciones y Auxiliar de Ferrocarriles (CAF)', TRUE, 10, 2023);

	-- Consulta Correspondiente
	/*
	SELECT * 
	FROM TREN 
	WHERE LOWER(Marca) IN ('caf', 'construcciones y auxiliar de ferrocarriles (caf)') 
	ORDER BY NumeroLinea desc;
	*/
